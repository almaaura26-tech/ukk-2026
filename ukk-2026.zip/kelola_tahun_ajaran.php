<?php
// kelola_tahun_ajaran.php
include 'includes/cek_session.php';
include 'config/koneksi.php';

$sql = "SELECT * FROM t_tahun_ajaran ORDER BY tanggal_mulai DESC";
$hasil = mysqli_query($koneksi, $sql);

if (!$hasil) {
    die("Query gagal: " . mysqli_error($koneksi));
}

// Notifikasi berhasil atau gagal
$pesan = $_GET['pesan'] ?? '';
$notifikasi = '';
$jenis_notifikasi = 'success';

if ($pesan === 'edit') {
    $notifikasi = 'Data siswa berhasil diperbarui.';
} elseif ($pesan === 'hapus' || $pesan === 'hapus_berhasil') {
    $notifikasi = 'Data siswa berhasil dihapus.';
} elseif ($pesan === 'tambah') {
    $notifikasi = 'Data siswa berhasil ditambahkan.';
} elseif ($pesan === 'hapus_gagal') {
    $notifikasi = 'Data siswa gagal dihapus atau tidak ditemukan.';
    $jenis_notifikasi = 'danger';
}

// Notifikasi dari session
if (!empty($_SESSION['pesan_sukses'])) {
    $notifikasi = $_SESSION['pesan_sukses'];
    $jenis_notifikasi = 'success';
    unset($_SESSION['pesan_sukses']);
} elseif (!empty($_SESSION['pesan_error'])) {
    $notifikasi = $_SESSION['pesan_error'];
    $jenis_notifikasi = 'danger';
    unset($_SESSION['pesan_error']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/2.3.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
</head>

<body>

<div class="container-fluid">
    <div class="row">

        <?php include 'layout/sidebar.php'; ?>

        <main class="col-md-9 col-lg-10 p-4">
                        
            <h1>Data Tahun ajaran</h1>
                <p>Selamat datang di halaman Tahun Ajaran.</p>
                <!-- NOTIFIKASI -->
            <?php if ($notifikasi !== '') { ?>

                <div class="alert alert-<?= htmlspecialchars($jenis_notifikasi) ?> alert-dismissible fade show"
                     role="alert">

                    <?= htmlspecialchars($notifikasi) ?>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="alert"
                            aria-label="Tutup">
                    </button>

                </div>

            <?php } ?>
          <?php
            if (isset($_SESSION['pesan_sukses'])) {
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                echo $_SESSION['pesan_sukses'];
                echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                echo '</div>';

                unset($_SESSION['pesan_sukses']);
            }

            if (isset($_SESSION['pesan_error'])) {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                echo $_SESSION['pesan_error'];
                echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                echo '</div>';

                unset($_SESSION['pesan_error']);
            }
            ?>
            <div class="mb-3">
                <a href="dashboard.php" class="btn btn-primary">
                    Kembali ke Dashboard
                </a>

                <a href="tambah_tahun_ajaran.php" class="btn btn-success">
                    + Tambah Tahun Ajaran
                </a>
            


                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table id="tabelTahunAjaran" class="table table-striped table-bordered table-hover">

                            <thead class="table-dark">
                                <tr>
                                    <th>No</th>
                                    <th>Tahun Ajaran</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Tanggal Selesai</th>
                                    <th>Status Aktif</th>
                                    <th>Dibuat</th>
                                    <th>Diubah</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($hasil)) { ?>
                                    <tr>
                                        <!-- Nomor otomatis diatur oleh DataTables -->
                                        <td></td>

                                        <td><?= htmlspecialchars($row['nama']) ?></td>

                                        <td><?= htmlspecialchars($row['tanggal_mulai'] ?? '') ?></td>

                                        <td><?= htmlspecialchars($row['tanggal_selesai'] ?? '') ?></td>

                                        <td>
                                            <?php if ($row['status_aktif'] == 1) { ?>
                                                <span class="badge bg-success">Aktif</span>
                                            <?php } else { ?>
                                                <span class="badge bg-danger">Tidak Aktif</span>
                                            <?php } ?>
                                        </td>

                                        <td><?= htmlspecialchars($row['created_at'] ?? '') ?></td>

                                        <td><?= htmlspecialchars($row['updated_at'] ?? '') ?></td>

                                        <td>
                                            <a href="edit_tahun_ajaran.php?id=<?= urlencode($row['id']) ?>"
                                               class="btn btn-primary btn-sm">
                                                Edit
                                            </a>

                                            <a href="hapus_tahun_ajaran.php?id=<?= urlencode($row['id']) ?>"
                                               class="btn btn-danger btn-sm"
                                               onclick="return confirm('Yakin ingin menghapus data tahun ajaran ini?');">
                                                Hapus
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>

                        </table>
                    </div>

                </div>
            </div>

        </main>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.min.js"></script>
<script src="https://cdn.datatables.net/2.3.4/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function () {

    $('#tabelTahunAjaran').DataTable({

        language: {
            search: "Cari:",
            lengthMenu: "Tampilkan _MENU_ data",
            info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
            infoEmpty: "Tidak ada data tahun ajaran",
            infoFiltered: "(difilter dari _MAX_ total data)",
            zeroRecords: "Data tahun ajaran tidak ditemukan",
            emptyTable: "Belum ada data tahun ajaran",

            paginate: {
                first: "Pertama",
                last: "Terakhir",
                next: "Berikutnya",
                previous: "Sebelumnya"
            }
        },

        pageLength: 10,

        // Urutkan berdasarkan tanggal mulai
        order: [[3, 'desc']],

        // Kolom No tidak bisa diurutkan atau dicari
        columnDefs: [
            {
                targets: 0,
                orderable: false,
                searchable: false
            }
        ],

        // Nomor otomatis mengikuti urutan data yang tampil
        drawCallback: function () {
            var api = this.api();
            var info = api.page.info();

            api.column(0, { page: 'current' }).nodes().each(function (cell, i) {
                cell.innerHTML = info.start + i + 1;
            });
        }

    });

});
</script>

</body>
</html>